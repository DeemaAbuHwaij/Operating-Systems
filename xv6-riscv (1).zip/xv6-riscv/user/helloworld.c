#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("Hello World xv6\n");
    exit(0, 0);
}
